package com.untd;
import com.untd.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class AdminMapper implements RowMapper {
	public Admin mapRow(ResultSet rs, int rowNum) throws SQLException {
		Admin admin = new Admin();
		admin.setUsername(rs.getString("adminname"));
		admin.setPassword(rs.getString("password"));
    
	     return admin;
	}

	
}
