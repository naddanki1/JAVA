package com.untd.controller;

import com.untd.User;
import com.untd.template.*;

import java.io.Console;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Controller
public class ReportController {
     ApplicationContext context = 
            new ClassPathXmlApplicationContext("Beans.xml");
	 UserJDBCTemplate userJDBCTemplate = 
		      (UserJDBCTemplate)context.getBean("userJDBCTemplate");

	 @RequestMapping(value="/userReport")
	 public String getUser (ModelMap model, HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting User Report");
	    	ArrayList report =  userJDBCTemplate.listUsers();
     		model.addAttribute("message", report);
         	return "userReportHome";	
    }
	 else {
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Cpu details : user not  logged in");  
		 return "redirect:/api/reportLoginHome";
     }
    }
	 
	 @RequestMapping(value="/getUserReport")
	 public String getUserReport (@RequestParam String  uid,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting user reports by userid: "+ uid);
	 		ArrayList users =  userJDBCTemplate.getUserReport(uid );
	      	model.addAttribute("message", users);
	      	return "userReportByUID";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Userdetails by uid : User not logged in");
	 		return "redirect:/api/reportLoginHome";
	 	}
	 }
	 @RequestMapping(value="/phoneReport")
	 public String getPhone (ModelMap model, HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Phone Report");
	    	ArrayList report =  userJDBCTemplate.listPhoneAll();
     		model.addAttribute("message", report);
         	return "phoneReportHome";	
    }
	 else {
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Cpu details : user not  logged in");  
		 return "redirect:/api/reportLoginHome";
     }
    }
	 
	 
	 @RequestMapping(value="/getPhoneReport")
	 public String getPhoneReport (@RequestParam String sno,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Phone reports by sno: "+ sno);
	 		ArrayList phones =  userJDBCTemplate.getPhoneReport(sno );
	      	model.addAttribute("message", phones);
	      	return "phoneReportBySno";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Phone details by sno: User not logged in");
	 		return "redirect:/api/reportLoginHome";
	 	}
	 }
	 
	 
	 @RequestMapping(value="/getPhoneHistoryReport")
	 public String getPhoneHistoryReport (@RequestParam String  sno,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Phone History reports by sno: "+ sno);
	 		int id = userJDBCTemplate.getPhoneID(sno);
	 		ArrayList phones =  userJDBCTemplate.getPhoneHistoryReport(id );
	      	model.addAttribute("message", phones);
	      	return "phoneHistoryReportBySno";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Phone History details by id : User not logged in");
	 		return "redirect:/api/reportLoginHome";
	 	}
	 }
	 @RequestMapping(value="/cpuReport")
	 public String getCPU (ModelMap model, HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Cpu Report");
	    	ArrayList report =  userJDBCTemplate.listCpus();
     		model.addAttribute("message", report);
         	return "cpuReportHome";	
    }
	 else {
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Cpu details : user not  logged in");  
		 return "redirect:/api/reportLoginHome";
     }
    }
	 
	 
	 @RequestMapping(value="/getCpuReport")
	 public String getCpuReport (@RequestParam String  sno,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting CPU reports by sno: "+ sno);
	 		ArrayList users =  userJDBCTemplate.getCpuReport(sno );
	 		System.out.println("Arraylist size is "+ users.size());
	      	model.addAttribute("message", users);
	      	return "cpuReportBySno";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Userdetails by uid : User not logged in");
	 		return "redirect:/api/reportLoginHome";
	 	}
	 }
	 
	 @RequestMapping(value="/getCpuHistoryReport")
	 public String getCpuHistoryReport (@RequestParam String  sno,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting CPU History reports by sno: "+ sno);
	 		int id = userJDBCTemplate.getCpuID(sno);
	 		
	 		ArrayList cpu =  userJDBCTemplate.getCpuHistoryReport(id);
	      	model.addAttribute("message", cpu);
	      	return "cpuHistoryReportBySno";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get CPU History details by id : User not logged in");
	 		return "redirect:/api/reportLoginHome";
	 	}
	 }
	 
	 @RequestMapping(value="/laptopReport")
	 public String getLaptop (ModelMap model, HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Laptop Report");
	    	ArrayList report =  userJDBCTemplate.listLaptopAll();
     		model.addAttribute("message", report);
         	return "laptopReportHome";	
    }
	 else {
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Laptop details : user not  logged in");  
		 return "redirect:/api/reportLoginHome";
     }
    }
	 
	 
	 @RequestMapping(value="/getLaptopReport")
	 public String getLaptopReport (@RequestParam String  sno,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Laptop reports by sno: "+ sno);
	 		ArrayList users =  userJDBCTemplate.getLaptopReport(sno );
	      	model.addAttribute("message", users);
	      	return "laptopReportBySno";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Laptop details by sno : User not logged in");
	 		return "redirect:/api/reportLoginHome";
	 	}
	 }
	 
	 @RequestMapping(value="/getLaptopHistoryReport")
	 public String getLaptopHistoryReport (@RequestParam String  sno,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Laptop History reports by sno: "+ sno);
	 		int id = userJDBCTemplate.getLaptopID(sno);
	 		
	 		ArrayList laptops =  userJDBCTemplate.getLaptopHistoryReport(id);
	 		
	      	model.addAttribute("message", laptops);
	      	return "laptopHistoryReportBySno";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Laptop History details by id : User not logged in");
	 		return "redirect:/api/reportLoginHome";
	 	}
	 }
	 
	 @RequestMapping(value="/monitorReport")
	 public String getMonitor (ModelMap model, HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Monitor Report");
	    	ArrayList report =  userJDBCTemplate.listMonitorAll();
     		model.addAttribute("message", report);
         	return "monitorReportHome";	
    }
	 else {
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Monitor details : user not  logged in");  
		 return "redirect:/api/reportLoginHome";
     }
    }
	 
	 
	 @RequestMapping(value="/getMonitorReport")
	 public String getMonitorReport (@RequestParam String  sno,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Monitor reports by sno: "+ sno);
	 		ArrayList monitor =  userJDBCTemplate.getMonitorReport(sno );
	      	model.addAttribute("message", monitor);
	      	return "monitorReportBySno";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Monitor details by id: User not logged in");
	 		return "redirect:/api/reportLoginHome";
	 	}
	 }
	 
	 @RequestMapping(value="/getMonitorHistoryReport")
	 public String getMonitorHistoryReport (@RequestParam String  sno,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Monitor History reports by sno: "+ sno);
            int id = userJDBCTemplate.getMonitorID(sno);	 
	 		ArrayList users =  userJDBCTemplate.getMonitorHistoryReport(id );
	      	model.addAttribute("message", users);
	      	return "monitorHistoryReportBySno";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Monitor History details by id : User not logged in");
	 		return "redirect:/api/reportLoginHome";
	 	}
	 }
	 
	 @RequestMapping(value="/reportLoginHome")
	 public String redirectToHome (ModelMap model){
	 	         	return "reportLoginHome";	
	 }
}