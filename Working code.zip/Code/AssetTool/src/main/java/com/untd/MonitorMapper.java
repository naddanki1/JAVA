package com.untd;
import com.untd.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class MonitorMapper implements RowMapper {
   public Monitor mapRow(ResultSet rs, int rowNum) throws SQLException {
      Monitor monitor = new Monitor();
      monitor.setId(rs.getInt("id"));
      monitor.setModel(rs.getString("model"));
      monitor.setVendor(rs.getString("vendor"));
      monitor.setSno(rs.getString("sno"));
      monitor.setSize(rs.getString("size"));
      monitor.setColor(rs.getString("color"));
      monitor.setPdate(rs.getString("pdate"));
      monitor.setWarranty(rs.getString("warranty"));
      monitor.setEdate(rs.getString("edate"));
      monitor.setStat(rs.getString("stat"));
      monitor.setBond(rs.getString("bond"));
      monitor.setUid1(rs.getString("uid1"));
      monitor.setUid2(rs.getString("uid2"));
          
      return monitor;
   }
}