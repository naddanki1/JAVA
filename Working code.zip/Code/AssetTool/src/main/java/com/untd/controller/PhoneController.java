package com.untd.controller;
import com.untd.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.ListIterator;

import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.untd.template.UserJDBCTemplate;

@Controller
public class PhoneController {
	ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
	UserJDBCTemplate userJDBCTemplate = (UserJDBCTemplate)context.getBean("userJDBCTemplate");
	 
	@RequestMapping(value = "/phoneAll")
	public String getPhoneAll(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){ 
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(new SimpleDateFormat("MM-dd-yyyy HH:mm:ss").format(java.util.Calendar.getInstance().getTime())+":  "+"Getting phone details by Admin "+adminid);
			String mode = "*";
			
			ArrayList phones =  userJDBCTemplate.listPhoneAll();
     		model.addAttribute("message", phones);
         	return "phoneAll";
         	}
	   else {
	 	    System.out.println(new SimpleDateFormat("MM-dd-yyyy").format(java.util.Calendar.getInstance().getTime())+":  "+"Failed to get Phone details: User not logged in");
		    return "redirect:/api/home";
		   }
      }
	
	@RequestMapping(value="/phoneAdd",produces = "application/json", params = {"id","model","vendor","sno","pdate","warranty","edate","stat","uid1"})
	 public @ResponseBody ()  	
	 String addPhone(@RequestParam (value = "id") int id,  @RequestParam(value = "model") String model, @RequestParam(value = "vendor") String vendor,@RequestParam(value = "sno") String sno,
			 @RequestParam(value = "pdate") String pdate, @RequestParam(value = "warranty") String warranty,
             @RequestParam(value = "edate") String edate, @RequestParam(value = "stat") String stat, 
			 @RequestParam(value = "uid1") String uid1,  HttpSession session) throws Exception{
		 
		 String loginAttribute = (String) session.getAttribute("login");
		 if (loginAttribute == "success"){ 
			 String adminid = (String) session.getAttribute("adminid");
			 String currentdate = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss").format(java.util.Calendar.getInstance().getTime());
			 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Adding Phone details by Admin "+adminid);
			
			 // adding phone details to history table//
			 userJDBCTemplate.addPhoneHistory(id,currentdate,uid1,stat,sno,adminid);
			 String response = userJDBCTemplate.addPhone(id,model,vendor,sno,pdate,warranty,edate,stat,uid1);
		     return response; 
	     }
		 else{
			 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to add Phone details: User not logged in");
			 return "noSessionId";
		 }
	 }
	
	@RequestMapping(value="/phoneAddHome")
	 public String cpuAddHome (ModelMap model, HttpSession session) {
		    String loginAttribute = (String) session.getAttribute("login");
		    if (loginAttribute == "success"){
		    	String adminid = (String) session.getAttribute("adminid");
		    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"getting Phone details by Admin "+adminid);
	 	       	return "phoneAddHome";	
		    }
		    else{
		    	 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get phone add page  :User not logged in");
		   		 return "redirect:/api/home";
		   		              
		   	}
	  }
	
	
	@RequestMapping(value="/phoneUpdate")
	public String getUpdateUserDetails (ModelMap model,HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){ 
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"getting phone  details to update by Admin"+adminid);
			ArrayList phones =  userJDBCTemplate.listPhoneAll();
	     	model.addAttribute("message", phones);
	        return "phoneUpdateHome";	
	    }
		else{
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get the phone details to update : user not logged in");
			return "redirect:/api/home";
			}
	}
	
	@RequestMapping(value="/phoneUpdateFinal",produces = "application/json",params = {"id","model","vendor","sno","pdate","warranty","edate","stat","uid1"})
	 public @ResponseBody ()  	
	 String updatePhone(@RequestParam (value = "id") int id,  @RequestParam(value = "model") String model, @RequestParam(value = "vendor") String vendor,@RequestParam(value = "sno") String sno,
			 @RequestParam(value = "pdate") String pdate, @RequestParam(value = "warranty") String warranty,
             @RequestParam(value = "edate") String edate, @RequestParam(value = "stat") String stat,
			 @RequestParam(value = "uid1") String uid1,  HttpSession session) throws Exception{
		 
		 String loginAttribute = (String) session.getAttribute("login");
		 if (loginAttribute == "success"){ 
			 String prevstat = "";
			 String adminid = (String) session.getAttribute("adminid");
			 ArrayList<Phone> phone = userJDBCTemplate.getPhone(sno);
			 ListIterator li = phone.listIterator();
			 for(Phone phn : phone ){
				
				prevstat = phn.getStat();  
				}
			 String currentdate = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss").format(java.util.Calendar.getInstance().getTime());
			 userJDBCTemplate.updatePhoneHistory(id,currentdate,uid1,prevstat,stat,sno,adminid);
		     System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Updating Phone details also History table  by Admin "+adminid);
			 String res =  userJDBCTemplate.updatePhone(id,model,vendor,sno,pdate,warranty,edate,stat,uid1);
	     		
	         	return res;	
	    }
		else{
			 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to update the phone details: User not logged in");
			 return "noSessionId";
		 }
	}
	@RequestMapping(value = "/phoneStore")
	public String getPhoneStore(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting stores phone details by Admin "+adminid);
			String mode = "Stores";
			ArrayList phones =  userJDBCTemplate.listPhone(mode);
     		model.addAttribute("message", phones);
         	return "phoneStores";	
        }
	   else {
	 	    System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get stores phone details : User  not logged in");
		    return "redirect:/api/home";
		   }
      }
	@RequestMapping(value = "/phoneDesktop")
	public String getPhoneDesktop(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting desktop phone details by Admin "+adminid);
			String mode = "Desktop";
			ArrayList phones =  userJDBCTemplate.listPhone(mode);
     		model.addAttribute("message", phones);
         	return "phoneDesktop";	
        }
	   else {
		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Desktop phone details : User  not logged in");
		    return "redirect:/api/home";
		   }
      }
	@RequestMapping(value = "/phoneFaulty")
	public String getPhoneFaulty(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){ 
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting faulty phone details by Admin "+adminid);
			String mode = "Faulty";
			ArrayList phones =  userJDBCTemplate.listPhone(mode);
     		model.addAttribute("message", phones);
         	return "phoneFaulty";	
        }
	   else {
		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Faulty phone details : User  not logged in");
		    return "redirect:/api/home";
		   }
      }
	
	@RequestMapping(value = "/phoneOut")
	public String getPhoneOut(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){ 
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting out phone details by Admin "+adminid);
			String mode = "Out";
			ArrayList phones =  userJDBCTemplate.listPhone(mode);
     		model.addAttribute("message", phones);
         	return "phoneOut";	
        }
	   else {
		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Out phone details : User  not logged in");
		    return "redirect:/api/home";
		   }
      }
	
	@RequestMapping(value="/getPhoneDetails")
	public String getUser (@RequestParam String  sno,ModelMap model,HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){ 
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting  phone details by sno "+ sno+ " by Admin "+adminid);
			ArrayList phones =  userJDBCTemplate.getPhone(sno );
	    	model.addAttribute("message", phones);
	    	return "phoneBySno";	
		}
		else {
				System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get phone details by Sno: user not logged in");
				return "redirect:/api/home";
		}
	}
	
}
	


