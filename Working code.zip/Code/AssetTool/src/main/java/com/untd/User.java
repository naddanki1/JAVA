package com.untd;


public class User {
int id;
String fname, lname, uid, team, role, stat, cube, jdate, edate;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public String getUid() {
	return uid;
}
public void setUid(String uid) {
	this.uid = uid;
}
public String getTeam() {
	return team;
}
public void setTeam(String team) {
	this.team = team;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public String getStat() {
	return stat;
}
public void setStat(String stat) {
	this.stat = stat;
}
public String getCube() {
	return cube;
}
public void setCube(String cube) {
	this.cube = cube;
}
public String getJdate() {
	return jdate;
}
public void setJdate(String jdate) {
	this.jdate = jdate;
}
public String getEdate() {
	return edate;
}
public void setEdate(String edate) {
	this.edate = edate;
} 
}
