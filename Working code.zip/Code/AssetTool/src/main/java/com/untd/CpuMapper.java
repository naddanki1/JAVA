package com.untd;
import com.untd.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class CpuMapper implements RowMapper {
   public Cpu mapRow(ResultSet rs, int rowNum) throws SQLException {
      Cpu cpu = new Cpu();
      cpu.setId(rs.getInt("id"));
      cpu.setModel(rs.getString("model"));
      cpu.setHostname(rs.getString("hostname"));
      cpu.setVendor(rs.getString("vendor"));
      cpu.setSno(rs.getString("sno"));
      cpu.setEdate(rs.getString("edate"));
      cpu.setProc_type(rs.getString("proc_type"));
      cpu.setHdd(rs.getString("hdd"));
      cpu.setRam(rs.getString("ram"));
      cpu.setDIMM(rs.getString("DIMM")); 
      cpu.setOs(rs.getString("os")); 
      cpu.setOs_key(rs.getString("os_key")); 
      cpu.setPdate(rs.getString("pdate")); 
      cpu.setWarranty(rs.getString("warranty")); 
      cpu.setEdate(rs.getString("edate")); 
      cpu.setStat(rs.getString("stat")); 
      cpu.setBond(rs.getString("bond"));
      cpu.setUid1(rs.getString("uid1")); 
      cpu.setUid2(rs.getString("uid2"));
      cpu.setBr(rs.getString("br"));
      cpu.setFlr(rs.getString("flr"));
      cpu.setLoc(rs.getString("loc"));
      cpu.setEa(rs.getString("ea"));
      
      return cpu;
   }
}