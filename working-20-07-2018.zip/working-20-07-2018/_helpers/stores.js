
import  updateProjectPageReducer from  '../_reducers/updateProjectPageReducer';
import  createProjectPageReducer  from '../_reducers/createProjectPageReducer';
import  createCabinetPageReducer from  '../_reducers/createCabinetPageReducer';
import  createFolderPageReducer from  '../_reducers/createFolderPageReducer';
import  createObjectTypePageReducer from  '../_reducers/createObjectTypePageReducer';



import { applyMiddleware, compose, combineReducers, createStore } from 'redux';
import thunk from 'redux-thunk';

const allReducers = combineReducers({
    
    project:  createProjectPageReducer,
    cabinet:  createCabinetPageReducer,
    folder: createFolderPageReducer,
    updateProject: updateProjectPageReducer,
    object:  createObjectTypePageReducer,
    
  
});

const initialState = { 
 // project:[{projectName:"naresh",description:"descr",email:"naresh@walmart.com"}],
 // object: [{projectName:"test",typeName:"test",attributes:[{name:"naresh",type:"type",size:"5",isRepeated:true}]}]
};

const allStoreEnhancers = compose(
 applyMiddleware(thunk),
 window.devToolsExtension && window.devToolsExtension()
);

export const store = createStore(allReducers,initialState,allStoreEnhancers);

