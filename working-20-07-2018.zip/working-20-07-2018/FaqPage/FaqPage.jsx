import React from 'react';
import { BrowserRouter as Router, Route, Switch, Link  } from 'react-router-dom'
import {browserHistory} from 'react-router-dom';
import { Document, Page } from 'react-pdf';
import Pdf from '../Documents/pdf-sample.pdf'
class FaqPage extends React.Component{

   constructor(props)
        {
         super(props);
         this.state = {
         whatIsProject:false,
         whatIsCabinet:false,
         whatIsFolder:false,
         whatIsObjectType:false
         };
         this.onChangeAction = this.onChangeAction.bind(this);
        }
   
   onChangeAction(e){
     
     name = e.target.name;
     if(name=="whatIsProject"){
       if(this.state.whatIsProject){
          this.setState({["whatIsProject"]:false});
       }
       else{
          this.setState({["whatIsProject"]:true});
       }
       
     }
     
     else if(name=="whatIsCabinet"){
       if(this.state.whatIsCabinet){
         this.setState({["whatIsCabinet"]:false});
       }
       else{
          this.setState({["whatIsCabinet"]:true});
       }
       
     }

     else if(name=="whatIsFolder"){
       if(this.state.whatIsFolder){
         this.setState({["whatIsFolder"]:false});
       }
       else{
          this.setState({["whatIsFolder"]:true});
       }
       
     }
     else if(name=="whatIsObjectType"){
       if(this.state.whatIsObjectType){
         this.setState({["whatIsObjectType"]:false});
       }
       else{
          this.setState({["whatIsObjectType"]:true});
       }
       
     }

    }
    render() {
       const { whatIsProject, whatIsCabinet, whatIsFolder, whatIsObjectType } = this.state;
       return (<div className={"col-md-8 col-md-offset-1 "}>
          <h2 >FAQs</h2><br/><br/>
          <div >
         
          <h5><a  name="whatIsProject" onClick={this.onChangeAction} >1. What is Project </a><br/></h5><br/>
          {whatIsProject && <div><p>Project is .... for more info click here <a href="../Documents/whatIsProject.pdf" target="_blank">pdf</a> </p> <br/></div>}
          <h5><a name="whatIsCabinet"  onClick={this.onChangeAction} >2. What is Cabinet </a><br/></h5><br/>
          {whatIsCabinet && <div><p>Cabinet is .... for more info click here <a href="../Documents/whatIsProject.pdf" target="_blank" >pdf</a> </p><br/> </div>}
          <h5><a name="whatIsFolder"  onClick={this.onChangeAction}  >3. What is Folder </a><br/></h5><br/>
          {whatIsFolder && <div><p>Folder is .... for more info click here <a href="../Documents/whatIsProject.pdf" target="_blank">pdf</a> </p><br/> </div>}
          <h5><a name="whatIsObjectType" onClick={this.onChangeAction}>4. What is Object Type </a><br/></h5><br/>
          {whatIsObjectType && <div><p>Object is .... for more info click here <a href="../Documents/whatIsProject.pdf" target="_blank">pdf</a> </p> <br/></div>}
        
          </div>
    </div>);
    
  }
}

export default FaqPage