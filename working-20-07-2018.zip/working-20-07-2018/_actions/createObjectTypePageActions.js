import $ from 'jquery';
export const ACTION_CHANGE = 'object:change';


export function change(PROJECT_NAME,OBJECT_TYPE,ATTRIBUTES) {

    
    return{
        type: ACTION_CHANGE,
        payload: {
            object: {projectName:PROJECT_NAME,objectType:OBJECT_TYPE,attributes:ATTRIBUTES}
        }
    };
}

export function apiRequest() {
return dispatch => {
var getUrl;
getUrl=   $.ajax({
        type: 'GET',
        crossDomain: true,
        headers:{'Content-Type': 'application/x-www-form-urlencoded'},
        url: 'http://dctm-mobile-rest.prod.walmart.com:8080/DctmRest/repositories',
        success(response){
                console.log('Success');
                console.log(response);
            },
            
        error(){
                console.log('Error');
                
            }
        });
    }


}

