import $ from 'jquery';
export const ACTION_CHANGE = 'folder:change';

export function change(PROJECT_NAME,CABINET_NAME,FOLDER_TAXONOMY,EMAIL,SUBMITTED) {
    
    return{
        type: ACTION_CHANGE,
        payload: {
             folder: {projectName:PROJECT_NAME,cabinetName:CABINET_NAME,folderTaxonomy:FOLDER_TAXONOMY,submitted:SUBMITTED}
                 
        }

    };
}

export function apiRequest(param1,param2,param3,param4) {
    console.log("Api params are "+param1,param2,param3,param4);
return dispatch => {

    $.ajax({
        type: 'GET',
        xhrFields: {
        withCredentials: true
        },
        crossDomain: true,
        headers: {
        'Authorization': 'Basic ' + btoa('dmadmin:tstr00t13'),
        //'Access-Control-Allow-Origin': 'http://dctm-mobile-rest.prod.walmart.com:8080/DctmRest/repositories/DCTM_DEMO/users',
       // 'Access-Control-Allow-Headers': "Origin, X-Requested-With, Content-Type, Accept",
      //  'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE'
        },
        url: 'http://dctm-mobile-rest.prod.walmart.com:8080/DctmRest/repositories',
         
        success(response){
                console.log('Success');
                console.log(response);
            },
        error(){
                console.log('Error');
            }
        });
    }


}



