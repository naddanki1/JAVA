import { ACTION_CHANGE } from '../_actions/updateProjectPageActions';



export default function updateProjectPageReducer(state = {}, action) {
  
  switch (action.type) {
    
    case ACTION_CHANGE:
      return (action.payload.updateProject);
    default:
      return state;
  }
}

