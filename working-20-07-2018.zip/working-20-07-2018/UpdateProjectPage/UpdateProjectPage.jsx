import React from 'react';
import { connect } from 'react-redux';
import { change, apiRequest } from '../_actions/updateProjectPageActions';
import {browserHistory} from 'react-router-dom';
import {findDOMNode} from 'react-dom'
import ReactTooltip from 'react-tooltip'


class UpdateProjectPage extends React.Component{

 constructor(props){
    super(props);
    this.projectName="";
    this.email="";
    this.description="";
    this.submitted=false;
    this.isAddCabinet=false;
    this.isAddFolderTaxonomy=false;
    this.addCabinet="";
    this.addFolder="";
    this.onChangeAction = this.onChangeAction.bind(this);
    this.handleRedirect  = this.handleRedirect.bind(this);
    this.handleToolTip = this.handleToolTip.bind(this);
    this.unhandleToolTip = this.unhandleToolTip.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    }


componentDidMount(){
   
   this.projectName=this.props.projectName;
   this.description=this.props.description;
   this.email=this.props.email;
   this.cabinetName=this.props.cabinetName;
   this.folderTaxonomy=this.props.folderTaxonomy;
   this.isAddCabinet=this.props.isAddCabinet;
   this.isAddFolderTaxonomy=this.props.isAddFolderTaxonomy;
   this.addCabinet=this.props.addCabinet;
   this.addFolder=this.props.addFolder;
   
      
}
onChangeAction(e){
    e.preventDefault();
       
    if(e.target.name=="projectName"){
       this.projectName = e.target.value;
    }
    else if(e.target.name=="email"){
       this.email= e.target.value;
    }
    else if (e.target.name=="description"){
        this.description=e.target.value;
    }
    else if(e.target.name=="cabinetName"){
       this.cabinetName= e.target.value;
    }
    else if (e.target.name=="folderTaxonomy"  ){
       
        this.folderTaxonomy=e.target.value;
     
        var noOfLevels = e.target.value.split("/").length -1 ;

		if(noOfLevels > 5 ){
			  alert("no of sub levels should not be more than 5");
		}
    }
    
    else if (e.target.name =="submitted"){
        this.submitted=e.target.value;
    }

    else if (e.target.name =="addCabinet"){
        this.addCabinet=e.target.value;
             
    }
    else if (e.target.name =="addFolder"){
        this.addFolder=e.target.value;
        var noOfLevels = e.target.value.split("/").length -1 ;

		if(noOfLevels > 5 ){
			  alert("no of sub levels should not be more than 5");
		}
    }

    else if (e.target.name =="isAddCabinetBtn"){
        this.isAddCabinet=true
    }

    else if (e.target.name =="addFolderBtn"){
        if(this.isAddCabinet==true){
        this.isAddFolderTaxonomy=true;
        }
    }

    else if (e.target.name=="clearBtn"){
       this.projectName = ""
       this.email =""
       this.description=""
       this.submitted=false
    }

    this.props.onChange(this.projectName,this.description,this.cabinetName, this.folderTaxonomy,this.email,this.isAddCabinet,this.isAddFolderTaxonomy,this.addCabinet,this.addFolder);
   
}


handleRedirect(e){
             e.preventDefault();
             const btnName = e.target.name;
             if(btnName == "cancelBtn"){
                this.props.history.push("/");
             }
              else if(btnName == "nextBtn"){
                this.submitted = true;
                if(/walmart.com|wal-mart.com|walmartlabs.com/.test(this.email)){
                    this.props.history.push("/createcabinet");
                }
                else{
                alert("Email should be of one of the these domains @walmart.com or @wal-mart.com or walmartlabs.com ");
                this.props.history.push("/createproject");
                }
             }
        
 }
 
 handleToolTip(e){
            e.preventDefault();
            const toolTipName = e.target.name;
            if(toolTipName == "projectToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.projectToolTip));
            }
            else if(toolTipName == "descriptionToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.descriptionToolTip));
            }
            else if(toolTipName == "emailToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.emailToolTip));
            }
            else if(toolTipName == "cabinetNameToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.cabinetNameToolTip));
            }
            else if(toolTipName == "folderTaxonomyToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.folderTaxonomyToolTip));
            }
            else if(toolTipName == "cancelCabinetBtn"){
                ReactTooltip.show(findDOMNode(this.refs.cancelCabinetToolTip));
            }
            else if(toolTipName == "cancelFolderBtn"){
                ReactTooltip.show(findDOMNode(this.refs.cancelFolderToolTip));
            }
  }

  unhandleToolTip(e){
            e.preventDefault();
            const toolTipName = e.target.name;
            if(toolTipName == "projectToolTip"){
                ReactTooltip.hide(findDOMNode(this.refs.projectToolTip));
            }
            else if(toolTipName == "descriptionToolTip"){
                ReactTooltip.hide(findDOMNode(this.refs.descriptionToolTip));
            }
            else if(toolTipName == "emailToolTip"){
                ReactTooltip.hide(findDOMNode(this.refs.emailToolTip));
            }
            else if(toolTipName == "cabinetNameToolTip"){
                ReactTooltip.hide(findDOMNode(this.refs.cabinetNameToolTip));
            }
            else if(toolTipName == "folderTaxonomyToolTip"){
                ReactTooltip.hide(findDOMNode(this.refs.folderTaxonomyToolTip));
            }
            else if(toolTipName == "cancelCabinetBtn"){
                ReactTooltip.hide(findDOMNode(this.refs.cancelCabinetToolTip));
            }
            else if(toolTipName == "cancelFolderBtn"){
                ReactTooltip.hide(findDOMNode(this.refs.cancelFolderToolTip));
            }
 }

 handleCancel(e){
        e.preventDefault();
        if (e.target.name =="cancelCabinetBtn"){
        this.isAddCabinet=false;
        this.isAddFolderTaxonomy=false;
        this.addCabinet="";
        this.addFolder=""
        }
        else if (e.target.name =="cancelFolderBtn"){
            this.isAddFolderTaxonomy=false;
            this.addFolder="";
        }
        this.props.onChange(this.projectName,this.description,this.email,this.cabinetName, this.folderTaxonomy,this.isAddCabinet,this.isAddFolderTaxonomy,this.addCabinet,this.addFolder);

 }

 handleSubmit(e){
    e.preventDefault();
    this.props.onApiRequest(this.projectName,this.cabinetName,this.folderTaxonomy,this.email,this.addCabinet,this.addFolder);

 } 


render(){
    
        return(<div >

        <h2 className={"col-md-4 col-md-offset-5"}>Update Project </h2>
        
        <ReactTooltip />
          
        <form name="form" className={"col-md-4 col-md-offset-4"}  onSubmit={this.handleSubmit}>

        <div className={'row' }>
               <label htmlFor = "projectName">Project Name   </label><br/>
               <div class="col-xs-10">
               <input type="text"   className="form-control" name="projectName" value={this.props.projectName}  onChange={this.onChangeAction} /> &nbsp;
               </div>
               <div >
               <input type="image"  name="projectToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>&nbsp;
               </div>
               <p ref='projectToolTip' data-tip='Project Name should be like this'></p>
                {this.props.submitted && !this.props.projectName &&
                                            <div className="help-block">Project Name is required</div>
                                        }
         </div> 
               
        
        <div className={'row'}>
                <div>
                <label htmlFor="description" >Description  </label><br/>
                </div>
                <div class="col-xs-10">
                <input type="text" className="form-control" name="description" value={this.props.description}  onChange={this.onChangeAction}/> &nbsp;
                </div>
                <div>
                <input type="image" name="descriptionToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>
                </div>
                <p ref='descriptionToolTip' data-tip='Description should be like this'></p>
                 {this.props.submitted && !this.props.description &&
                                            <div className="help-block">Description is required</div>
                                        }
         </div>

        <div className={'row'}>
               <label htmlFor="cabinetName">Cabinet Name </label><br/>
               <div class="col-xs-10">
               <input type="text"  className="form-control" name="cabinetName" value={this.props.cabinetName}  onChange={this.onChangeAction}/> &nbsp;
               </div>
               <div>
               <input type="image" name="cabinetNameToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>&nbsp;
               </div>
               <p ref='cabinetNameToolTip' data-tip='Cabinet Name should be like this'></p>
               {this.props.submitted && !this.props.cabinetName &&
                                            <div className="help-block">Cabinet Name is required</div>
                                        }
        </div>

        <div className={'row'}>
                <label htmlFor="folderTaxonomy">Folder Taxonomy </label><br/>
                <div class="col-xs-10">
                <input type="text"  className="form-control" name="folderTaxonomy" value={this.props.folderTaxonomy}  onChange={this.onChangeAction}/> &nbsp;
                </div>
                <div>
                <input type="image" name="folderTaxonomyToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>&nbsp;
                </div>
                <p ref='folderTaxonomyToolTip' data-tip='Folder Taxonomy should be like this'></p>
                 {this.props.submitted && !this.props.folderTaxonomy &&
                                            <div className="help-block">Folder Taxonomy is required</div>
                                        }
        </div>

        <div className={'row'}>
                <label htmlFor="email">  Email Id</label><br/>
                <div class="col-xs-10">
                <input type="email"  className="form-control" name="email" value={this.props.email}  onChange={this.onChangeAction} /> &nbsp;
                </div>
                <div >
                <input type="image"  name="emailToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>&nbsp;
                </div>
                <p ref='emailToolTip' data-tip='email should be like this'></p> 
                 {this.props.submitted && !this.props.email &&
                                            <div className="help-block">Email is required</div>
                                        }
        </div>

        <div>
           {this.props.isAddCabinet && 
               <div className={'row'}> 
                  <label htmlFor="folderTaxonomy">Add Cabinet </label><br/> 
                  <div class="col-xs-10">
                     <input type="text" name="addCabinet" className="form-control" onChange={this.onChangeAction} /> &nbsp;
                  </div>  
                  <div >
                     <input type="image" name="cancelCabinetBtn" src="../images/cancel.jpg" onClick={this.handleCancel} onMouseOver={this.handleToolTip} onMouseOut={this.unhandleToolTip}  /><span/><br/> 
                     <p ref='cancelCabinetToolTip' data-tip='Cancel'></p>
                 </div>
                </div>
            }
         </div>
           
                
        <div>
           {this.props.isAddCabinet && this.props.isAddFolderTaxonomy && 
               <div className={'row'} >
                   <label htmlFor="folderTaxonomy">Add Folder </label><br/> 
                   <div class="col-xs-10">
                      <input type="text" name="addFolder" className="form-control" onChange={this.onChangeAction} />  
                   </div>
                   <div >
                      <input type="image" name="cancelFolderBtn" src="../images/cancel.jpg" onClick={this.handleCancel} onMouseOver={this.handleToolTip} onMouseOut={this.unhandleToolTip} /><span/>
                      <p ref='cancelFolderToolTip' data-tip='Cancel'></p>
                   </div>
               </div>
            }
        </div>
        
        <div>
           {!this.props.isAddCabinet && 
               <div><br/> 
                  <button className="btn btn-primary" name="isAddCabinetBtn" onClick={this.onChangeAction}>Add Cabinet</button> <span/>
               </div> 
           }
                    
           {this.props.isAddCabinet && !this.props.isAddFolderTaxonomy &&
               <div><br/>
                  <button className="btn btn-primary" name="addFolderBtn" onClick={this.onChangeAction}>Add Folder Taxonomy</button> <span/>
                </div>
            }
        
           <br/>
        </div>
        <br/>
       

        <div>
           <button className="btn btn-primary" >Update</button> <span/>
                      
        </div>
     </form>
           
   </div>);
        }


}

const mapStateToProps = (state,props) => {
      
    return {
        projectName: state.project.projectName,
        description: state.project.description,
        email: state.project.email,
        cabinetName: state.cabinet.cabinetName,
        folderTaxonomy: state.folder.folderTaxonomy,
        isAddCabinet:state.updateProject.isAddCabinet,
        isAddFolderTaxonomy:state.updateProject.isAddFolder,
        addCabinet:state.updateProject.addCabinet,
        addFolder:state.updateProject.addFolder
    }
};

const mapActionsToProps =  {
         onChange : change,
         onApiRequest: apiRequest
};

export default connect(mapStateToProps, mapActionsToProps ) (UpdateProjectPage);