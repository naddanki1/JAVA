var HtmlWebpackPlugin = require('html-webpack-plugin');
var config = {
   entry: './main.js',
   output: {
      path:'/',
      publicPath:'/',
      filename: 'index.js',
   },
   devServer: {
      inline: true,
      port: 7788,
      historyApiFallback:{
            index:'./index.html'
        },
      headers: {
        //"Access-Control-Allow-Origin" : "http://localhost:7788",
        //Vary: Origin,
        "Access-Control-Allow-Credentials": "true",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS"
       },
   },
   
   
   module: {
      rules: [
         {
            test: /\.jsx?$/,
            exclude: /node_modules/,
            loader: 'babel-loader',
            query: {
               presets: ['es2015', 'react'],
               plugins: ['transform-object-rest-spread','babel-plugin-transform-class-properties']
            }
          
         },
         {
            test: /\.pdf$/,
            use: 'url-loader',
         },
      ]
   }
}
module.exports = config;
