
import React from 'react';
import { BrowserRouter as Router, Route, Switch, Link  } from 'react-router-dom'

class ContactUsPage extends React.Component{
      render(){
    
        return(<div >
        <div className={"col-md-6 col-md-offset-1 vdivide"}>
        <h3>Contact Us</h3>
        
        <form name="form" >
        
        <div class="col-xs-8 ">
               <label htmlFor = "name"> Name   </label><br/>
               <div >
               <input type="text"   className="form-control" name="name" /> &nbsp;
               </div>
               
               <br/>
                          
         </div> 
         <br/>
        <div class="col-xs-8 ">
               <label htmlFor = "email"> Email   </label><br/>
               <div >
               <input type="text"   className="form-control" name="email" /> &nbsp;
               </div>
               
               <br/>
                          
         </div> 
       
        
        <div class="col-xs-8 " >
                <div>
                <label htmlFor="message" >Message  </label><br/>
                </div>
                <div >
                <textarea name="message" className="form-control" rows="3" cols="3" /> &nbsp;
                </div>
                
                
         </div>
        
        <div class="col-xs-8 " >
                <div>
                 <button className="btn btn-primary" name="sendBtn"  >Send</button> <span/>
                </div>
                
         </div>
        
        </form>
        </div>
        <div className={" col-md-offset-8 "}>
        <h3 > Get in touch  </h3>
        <br/>
        <p><img  src="../images/call.png"/> +1 222 333 444</p>
        <p><img  src="../images/email.png"/>  helpdesk@walmart.support.com</p>
        </div>
        </div>);
 }
}

export default ContactUsPage;